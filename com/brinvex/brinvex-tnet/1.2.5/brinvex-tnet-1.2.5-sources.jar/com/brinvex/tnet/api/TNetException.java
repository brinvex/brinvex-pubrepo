package com.brinvex.tnet.api;

import java.io.IOException;

public class TNetException extends IOException {

    private final TNetRequest<?, ?> req;

    private final TNetResponse<?> resp;

    public TNetException(String message, TNetRequest<?, ?> req, TNetResponse<?> resp) {
        super(message);
        this.req = req;
        this.resp = resp;
    }

    public TNetException(String message, Throwable cause, TNetRequest<?, ?> req, TNetResponse<?> resp) {
        super(message, cause);
        this.req = req;
        this.resp = resp;
    }

    public TNetRequest<?, ?> getReq() {
        return req;
    }

    @SuppressWarnings("unchecked")
    public <T> TNetResponse<T> getResp() {
        return (TNetResponse<T>) resp;
    }

    public Integer getRespStatusCode() {
        return resp == null ? null : resp.getStatusCode();
    }

    @SuppressWarnings("unchecked")
    public <T> T getRespBody() {
        return resp == null ? null : (T) resp.getBody();
    }


}
