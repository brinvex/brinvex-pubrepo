package com.brinvex.tnet.internal;

import java.util.regex.Pattern;

class RegexPatterns {

    static final Pattern READINESS_PROBE_BODY_PATTERN_SOCKS = Pattern.compile(
            "^<html>\\s+<head>\\s+<title>This is a SOCKS Proxy, Not An HTTP Proxy</title>.*", Pattern.DOTALL);

    static final Pattern READINESS_PROBE_BODY_PATTERN_HTTP = Pattern.compile(
            "^<html>\\s+<head>\\s+<title>This is an HTTP CONNECT tunnel, not a full HTTP Proxy</title>.*", Pattern.DOTALL);
}
