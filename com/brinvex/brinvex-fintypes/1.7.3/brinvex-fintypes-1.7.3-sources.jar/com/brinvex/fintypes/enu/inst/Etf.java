package com.brinvex.fintypes.enu.inst;

import com.brinvex.fintypes.enu.Country;
import com.brinvex.fintypes.enu.IndustrySector;
import com.brinvex.fintypes.vo.FullSymbol;

public enum Etf {
    /**
     * iShares Core S&P 500 UCITS ETF USD (Acc)
     */
    SXR8_DE("SXR8", Country.DE, "BBG000QXM7S8", IndustrySector.CROSS_SECTOR),

    /**
     * iShares NASDAQ 100 UCITS ETF USD (Acc)
     */
    SXRV_DE("SXRV", Country.DE, "BBG000QCQ4L4", IndustrySector.CROSS_SECTOR),

    /**
     * Lyxor Nasdaq-100 Daily (2x) Leveraged UCITS ETF (Acc)
     */
    L8I7_DE("L8I7", Country.DE, "BBG00835WGC3", IndustrySector.CROSS_SECTOR),

    /**
     * SPDR S&P U.S. Materials Select Sector UCITS ETF
     */
    ZPDM_DE("ZPDM", Country.DE, "BBG009HXTRJ8", IndustrySector.MATERIALS),

    /**
     * SPDR S&P U.S. Communication Services Select Sector UCITS ETF
     */
    ZPDK_DE("ZPDK", Country.DE, "BBG00LPLNRV0", IndustrySector.COMMUNICATION_SERVICES),

    /**
     * SPDR S&P U.S. Energy Select Sector UCITS ETF
     */
    ZPDE_DE("ZPDE", Country.DE, "BBG009HXT6B2", IndustrySector.ENERGY),

    /**
     * SPDR S&P U.S. Industrials Select Sector UCITS ETF
     */
    ZPDI_DE("ZPDI", Country.DE, "BBG009HXTLF5", IndustrySector.INDUSTRIALS),

    /**
     * SPDR S&P U.S. Financials Select Sector UCITS ETF
     */
    ZPDF_DE("ZPDF", Country.DE, "BBG009HXTCH3", IndustrySector.FINANCIALS),

    /**
     * SPDR S&P U.S. Consumer Staples Select Sector UCITS ETF
     */
    ZPDS_DE("ZPDS", Country.DE, "BBG009HXSVM6", IndustrySector.CONSUMER_STAPLES),

    /**
     * Invesco Real Estate S&P US Select Sector UCITS ETF
     */
    S6X2_DE("S6X2", Country.DE, "BBG00CCSC3P1", IndustrySector.REAL_ESTATE),

    /**
     * SPDR S&P U.S. Technology Select Sector UCITS ETF
     */
    ZPDT_DE("ZPDT", Country.DE, "BBG009HXTXR6", IndustrySector.INFORMATION_TECHNOLOGY),

    /**
     * SPDR S&P U.S. Utilities Select Sector UCITS ETF
     */
    ZPDU_DE("ZPDU", Country.DE, "BBG009HXV3W3", IndustrySector.UTILITIES),

    /**
     * SPDR S&P U.S. Health Care Select Sector UCITS ETF
     */
    ZPDH_DE("ZPDH", Country.DE, "BBG009HXTHH2", IndustrySector.HEALTH_CARE),

    /**
     * SPDR S&P U.S. Consumer Discretionary Select Sector UCITS ETF
     */
    ZPDD_DE("ZPDD", Country.DE, "BBG009HXSKV0", IndustrySector.CONSUMER_DISCRETIONARY);

    private final FullSymbol fullSymbol;

    private final String countryFigi;

    private final IndustrySector sector;

    Etf(String symbol, Country country, String countryFigi, IndustrySector sector) {
        this.countryFigi = countryFigi;
        this.fullSymbol = new FullSymbol(symbol, country);
        this.sector = sector;
    }

    public FullSymbol fullSymbol() {
        return fullSymbol;
    }

    public String symbol() {
        return fullSymbol.symbol();
    }

    public Country country() {
        return fullSymbol.country();
    }

    public String countryFigi() {
        return countryFigi;
    }

    public IndustrySector sector() {
        return sector;
    }
}
