package com.brinvex.fintypes.enu;

public enum InterestRateType {

    /**
     * FEDERAL_FUNDS_RATE is one of key interest rate in US.
     * <a href="https://www.investopedia.com/terms/f/federalfundsrate.asp">https://www.investopedia.com/terms/f/federalfundsrate.asp</a>
     */
    FEDERAL_FUNDS_RATE,

    /**
     * DEPOSIT_FACILITY_RATE is one of key interest rate in EU.
     * <a href="https://www.europarl.europa.eu/RegData/etudes/IDAN/2023/755707/IPOL_IDA(2023)755707_EN.pdf">https://www.europarl.europa.eu/RegData/etudes/IDAN/2023/755707/IPOL_IDA(2023)755707_EN.pdf</a>
     */
    DEPOSIT_FACILITY_RATE,
}
