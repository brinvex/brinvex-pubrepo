package com.brinvex.fintypes.vo;

import java.math.BigDecimal;
import java.time.LocalDate;

public record Price(
        LocalDate date,
        BigDecimal close,
        BigDecimal adjClose,
        Long id,
        Integer instId,
        LocalDate nextDate
) {

    public Price(LocalDate date, BigDecimal close, BigDecimal adjClose, LocalDate nextDate) {
        this(date, close, adjClose, null, null, nextDate);
    }

    public Price(LocalDate date, BigDecimal close, BigDecimal adjClose) {
        this(date, close, adjClose, null, null, null);
    }

    public Price(LocalDate date, BigDecimal close) {
        this(date, close, null, null, null, null);
    }

    public Price(BigDecimal close, BigDecimal adjClose) {
        this(null, close, adjClose, null, null, null);
    }

    public Price(BigDecimal close) {
        this(null, close, null, null, null, null);
    }

    @Override
    public String toString() {
        return "Price{%s,%s,adj=%s,instId=%s,id=%s, nextDate=%s}"
                .formatted(date, close, adjClose, instId, id, nextDate);
    }
}
