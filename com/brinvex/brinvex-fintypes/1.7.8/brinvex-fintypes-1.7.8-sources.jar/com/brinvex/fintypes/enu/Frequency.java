package com.brinvex.fintypes.enu;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.IsoFields;

import static java.util.Objects.requireNonNull;

public enum Frequency {

    DAY(Period.ofDays(1)),

    MONTH(Period.ofMonths(1)),

    QUARTER(Period.ofMonths(3)),

    YEAR(Period.ofYears(1));

    private final Period period;

    Frequency(Period period) {
        this.period = period;
    }

    public Period period() {
        return period;
    }

    public LocalDate adjustToStartDateIncl(LocalDate date) {
        return switch (this) {
            case DAY -> requireNonNull(date);
            case MONTH -> date.withDayOfMonth(1);
            case QUARTER -> date.with(IsoFields.DAY_OF_QUARTER, 1);
            case YEAR -> date.withDayOfYear(1);
        };
    }

    public LocalDate adjustToEndDateIncl(LocalDate date) {
        return switch (this) {
            case DAY -> requireNonNull(date);
            case MONTH -> date.withDayOfMonth(1).plusMonths(1).minusDays(1);
            case QUARTER -> date.with(IsoFields.DAY_OF_QUARTER, 1).plusMonths(3).minusDays(1);
            case YEAR -> date.withDayOfYear(1).plusYears(1).minusDays(1);
        };
    }

    public String caption(LocalDate date) {
        return switch (this) {
            case DAY -> Lazy.DAY_CAPTION_FMT.format(date);
            case MONTH -> Lazy.MONTH_CAPTION_FMT.format(date);
            case QUARTER -> Lazy.QUARTER_CAPTION_FMT.format(date);
            case YEAR -> String.valueOf(date.getYear());
        };
    }

    public int countPerYear() {
        return switch (this) {
            case DAY -> throw new UnsupportedOperationException(
                    "countPerYear is undefined for DAY because the number of days per year is not always the same"
            );
            case MONTH -> 12;
            case QUARTER -> 4;
            case YEAR -> 1;
        };
    }

    private static class Lazy {
        private static final DateTimeFormatter DAY_CAPTION_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        private static final DateTimeFormatter MONTH_CAPTION_FMT = DateTimeFormatter.ofPattern("yyyy-MM");
        private static final DateTimeFormatter QUARTER_CAPTION_FMT = DateTimeFormatter.ofPattern("yyyy-Q");
    }
}

