package com.brinvex.fintypes.enu;

public enum FinTransactionType {

    DEPOSIT,

    WITHDRAWAL,

    BUY,

    SELL,

    FX_BUY,

    FX_SELL,

    DIVIDEND,

    INTEREST,

    FEE,

    TAX,

    SYMBOL_CHANGE,

    TRANSFORMATION,

    OTHER_INTERNAL_FLOW;

}
