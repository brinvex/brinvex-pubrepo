package com.brinvex.fintypes.vo;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Function;

public record DateValue(
        LocalDate date,
        BigDecimal price
) {

    public DateValue(String date, String amount) {
        this(LocalDate.parse(date), new BigDecimal(amount));
    }

    public DateValue(Map.Entry<LocalDate, BigDecimal> mapEntry) {
        this(mapEntry.getKey(), mapEntry.getValue());
    }

    public boolean isBefore(LocalDate date) {
        return this.date.isBefore(date);
    }

    public boolean isAfter(LocalDate date) {
        return this.date.isAfter(date);
    }

    public DateValue combine(DateValue other, BiFunction<BigDecimal, BigDecimal, BigDecimal> priceOperation) {
        if (!date.isEqual(other.date())) {
            throw new IllegalArgumentException(
                    "Add operation not allowed for different dates: %s, %s.".formatted(this, other)
            );
        }
        return new DateValue(date, priceOperation.apply(price, other.price));
    }

    public DateAmount with(Function<BigDecimal, BigDecimal> priceOperation) {
        return new DateAmount(date, priceOperation.apply(price));
    }

    @Override
    public String toString() {
        return "DatePrice{%s/%s}".formatted(date, price == null ? null : price.toPlainString());
    }
}
