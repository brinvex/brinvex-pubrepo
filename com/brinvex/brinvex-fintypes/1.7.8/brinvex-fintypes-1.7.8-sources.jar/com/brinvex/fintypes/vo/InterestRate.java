package com.brinvex.fintypes.vo;

import com.brinvex.fintypes.enu.InterestRateType;

import java.math.BigDecimal;
import java.time.LocalDate;

public record InterestRate(
        InterestRateType type,
        LocalDate date,
        LocalDate nextDate,
        BigDecimal rate
) {

    public InterestRate(InterestRateType type, BigDecimal rate) {
        this(type, null, null, rate);
    }

    public InterestRate(InterestRateType type, LocalDate date, BigDecimal rate) {
        this(type, date, date, rate);
    }

    @Override
    public String toString() {
        return "%s[%s,%s)%s".formatted(type, date, nextDate, rate);
    }
}
