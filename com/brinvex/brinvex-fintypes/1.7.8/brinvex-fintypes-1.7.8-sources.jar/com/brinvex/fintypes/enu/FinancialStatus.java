package com.brinvex.fintypes.enu;

/**
 * Represents the financial status of a company or financial instrument.
 */
public enum FinancialStatus {

    /**
     * The financial status is considered normal and healthy.
     */
    NORMAL,

    /**
     * The financial status is below optimal, indicating some deficiencies.
     */
    DEFICIENT,

    /**
     * The financial status is delinquent, likely due to missed obligations or payments.
     */
    DELINQUENT,

    /**
     * The financial status is bankrupt.
     */
    BANKRUPT,

    /**
     * The financial status was inferred as bankrupt by the target system.
     * The actual financial status outside the system could be anything, but it is treated as bankrupt
     * within the system for processing purposes.
     */
    INFERRED_BANKRUPT
}
