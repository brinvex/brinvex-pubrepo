package com.brinvex.fintypes.vo;

import com.brinvex.fintypes.enu.Currency;

import java.math.BigDecimal;
import java.time.LocalDate;

public record FxRate(
        Currency baseCcy,
        Currency quoteCcy,
        LocalDate date,
        LocalDate nextDate,
        BigDecimal rate
) {

    public FxRate(Currency baseCcy, Currency quoteCcy, BigDecimal rate) {
        this(baseCcy, quoteCcy, null, null, rate);
    }

    public FxRate(Currency baseCcy, Currency quoteCcy, LocalDate date, BigDecimal rate) {
        this(baseCcy, quoteCcy, date, date, rate);
    }

    public FxRate(CurrencyPair ccyPair, LocalDate date, LocalDate nextDate, BigDecimal rate) {
        this(ccyPair.baseCcy(), ccyPair.quoteCcy(), date, nextDate, rate);
    }

    public FxRate(CurrencyPair ccyPair, LocalDate date, BigDecimal rate) {
        this(ccyPair.baseCcy(), ccyPair.quoteCcy(), date, date, rate);
    }

    @Override
    public String toString() {
        return "%s/%s[%s,%s)%s".formatted(baseCcy, quoteCcy, date, nextDate, rate);
    }
}
