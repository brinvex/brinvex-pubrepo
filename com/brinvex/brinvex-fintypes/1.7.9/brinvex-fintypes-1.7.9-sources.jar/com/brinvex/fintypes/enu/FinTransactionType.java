package com.brinvex.fintypes.enu;

public enum FinTransactionType {

    DEPOSIT,

    WITHDRAWAL,

    BUY,

    SELL,

    FX_BUY,

    FX_SELL,

    DIVIDEND,

    INTEREST,

    FEE,

    TAX,

    SYMBOL_CHANGE,

    TRANSFORMATION,

    /**
     * Loan principal taken on. qty carries the principal, grossValue the part of it that moves as
     * cash on this row - zero when the cash arrives through a separately tracked account.
     */
    LOAN_DRAW,

    /**
     * Loan principal paid back, qty negative. Interest is never part of this row - it is booked
     * separately as a negative {@link #INTEREST}.
     */
    LOAN_REPAY,

    OTHER_INTERNAL_FLOW;

}
