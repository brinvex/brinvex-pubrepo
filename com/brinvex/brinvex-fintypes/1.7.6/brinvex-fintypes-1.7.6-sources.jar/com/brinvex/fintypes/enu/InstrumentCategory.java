package com.brinvex.fintypes.enu;

import static com.brinvex.fintypes.enu.Currency.CZK;
import static com.brinvex.fintypes.enu.Currency.EUR;
import static com.brinvex.fintypes.enu.Currency.USD;
import static com.brinvex.fintypes.enu.InstrumentType.BOND;
import static com.brinvex.fintypes.enu.InstrumentType.ETF;
import static com.brinvex.fintypes.enu.InstrumentType.FUND;
import static com.brinvex.fintypes.enu.InstrumentType.IND;
import static com.brinvex.fintypes.enu.InstrumentType.STK;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;

public enum InstrumentCategory {

    STK_USD(STK, USD, (byte) 11),
    STK_EUR(STK, EUR, (byte) 12),
    STK_CZK(STK, CZK, (byte) 13),
    ETF_USD(ETF, EUR, (byte) 21),
    ETF_EUR(ETF, EUR, (byte) 22),
    FUND_EUR(FUND, EUR, (byte) 32),
    BOND_EUR(BOND, EUR, (byte) 42),
    IND_USD(IND, USD, (byte) 51);

    private final InstrumentType type;
    private final Currency ccy;
    private final byte code;

    private static final Map<InstrumentType, Map<Currency, InstrumentCategory>> BY_TYPE_AND_CCY;
    private static final Map<Byte, InstrumentCategory> BY_CODE;

    static {
        // (InstrumentType, Currency) -> InstrumentCategory
        Map<InstrumentType, Map<Currency, InstrumentCategory>> byTypeAndCcy =
                new EnumMap<>(InstrumentType.class);

        // code -> InstrumentCategory
        Map<Byte, InstrumentCategory> byCode = new HashMap<>();

        for (InstrumentCategory ic : values()) {
            byTypeAndCcy
                    .computeIfAbsent(ic.type, t -> new EnumMap<>(Currency.class))
                    .put(ic.ccy, ic);

            if (byCode.put(ic.code, ic) != null) {
                throw new IllegalStateException("Duplicate InstrumentCategory code: " + ic.code);
            }
        }

        BY_TYPE_AND_CCY = Map.copyOf(byTypeAndCcy);
        BY_CODE = Map.copyOf(byCode);
    }

    public static InstrumentCategory of(InstrumentType type, Currency ccy) {
        Map<Currency, InstrumentCategory> byCcy = BY_TYPE_AND_CCY.get(type);
        if (byCcy != null) {
            InstrumentCategory ic = byCcy.get(ccy);
            if (ic != null) {
                return ic;
            }
        }
        throw new IllegalArgumentException(
                "Instrument category not defined for: %s, %s".formatted(type, ccy)
        );
    }

    public static InstrumentCategory of(InstrumentType type, Country country) {
        return of(type, country.ccy());
    }

    public static InstrumentCategory of(int code) {
        InstrumentCategory ic = BY_CODE.get((byte) (code % 100));
        if (ic != null) {
            return ic;
        }
        throw new IllegalArgumentException(
                "Instrument category not defined for: code=%s".formatted(code)
        );
    }

    InstrumentCategory(InstrumentType type, Currency ccy, byte code) {
        this.type = type;
        this.ccy = ccy;
        this.code = code;
    }

    public InstrumentType type() {
        return type;
    }

    public Currency ccy() {
        return ccy;
    }

    public byte code() {
        return code;
    }

    @Override
    public String toString() {
        return "%s{%s}".formatted(name(), code);
    }
}
