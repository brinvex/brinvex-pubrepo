package com.brinvex.fintypes.enu;

public enum FinTransactionType {

    DEPOSIT,

    WITHDRAWAL,

    BUY,

    SELL,

    FX_BUY,

    FX_SELL,

    DIVIDEND,

    /**
     * Interest earned - on cash, savings or a broker balance. Positive; a negative one reverses
     * interest received earlier.
     */
    INTEREST_RECEIVED,

    /**
     * Interest owed - on a loan, or as broker debit interest. Negative; a positive one refunds
     * interest paid earlier.
     */
    INTEREST_PAID,

    FEE,

    TAX,

    SYMBOL_CHANGE,

    TRANSFORMATION,

    /**
     * Loan principal taken on. qty carries the principal, grossValue the part of it that moves as
     * cash on this row - zero when the cash arrives through a separately tracked account.
     */
    LOAN_DRAW,

    /**
     * Loan principal paid back, qty negative. Interest is never part of this row - it is booked
     * separately as {@link #INTEREST_PAID}.
     */
    LOAN_REPAY,

    OTHER_INTERNAL_FLOW;

}
